import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='isuryanarayanan',
    application_name='kabootar-api',
    app_uid='pBKlBB02PXbSkZWrZ4',
    org_uid='92e7d8f9-cd72-4bd2-96f5-6ad1b5f1f461',
    deployment_uid='1e819475-c79b-4973-b046-4630947155fd',
    service_name='kabootar-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'kabootar-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
